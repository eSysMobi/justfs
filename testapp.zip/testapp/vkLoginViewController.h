//
//  vkLoginViewController.h
//  motivateme2
//
//  Created by Valeriy on 20.11.13.
//  Copyright (c) 2013 esys.mobi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface vkLoginViewController : UIViewController{
    IBOutlet UIWebView *vkWebView;
    BOOL isCaptcha;
}
@end
